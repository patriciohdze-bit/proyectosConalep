Nacimiento AR - Proyecto listo para Glitch

Instrucciones rápidas:
1) Subir la carpeta completa NacimientoAR a Glitch (o arrastrar files a un nuevo proyecto).
2) Abrir el enlace desde el celular (Chrome o Safari).
3) Permitir acceso a la cámara.
4) Mover la cámara hasta detectar el suelo.
5) Tocar la pantalla donde quieras colocar el nacimiento.

Notas:
- Implementa WebXR hit-test cuando esté disponible (más preciso).
- Incluye un método fallback por si el dispositivo no soporta WebXR.
- Si el modelo se ve muy grande o pequeño, ajusta el atributo 'scale' en la etiqueta <a-obj-model>.
